var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var postSchema = new Schema({
    Id: Number,
    PostTypeId: Number,
    AcceptedAnswerId: Number,
    ParentId: Number,
    CreationDate: Date,
    DeletionDate: Date,
    Score: Number,
    ViewCount: Number,
    Body: String,
    OwnerUserId: Number,
    OwnerDisplayName: String,
    LastEditorUserId: Number,
    LastEditorDisplayName: String,
    LastEditDate: Date,
    LastActivityDate: Date,
    Title:  String,
    Tags: String,
    AnswerCount: Number,
    CommentCount: Number,
    FavoriteCount: Number,
    ClosedDate: Date,
    CommunityOwnedDate: Date
});

module.exports = mongoose.model('Post', postSchema, 'posts');
