var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var url = 'mongodb://127.0.0.1:27017/test';

exports.with_db = function (callback) {
    MongoClient.connect(url, function(err, database) {
        assert.equal(null, err);
        callback(database);
    });
};
