var express = require('express');
var mongoose = require('mongoose');

var router = express.Router();
var db = mongoose.connection;

var thm_map = function () {
    var date = new ISODate(this.CreationDate);
    var dayOfWeek = date.getDay();
    var hour = date.getHours();

    if (dayOfWeek === 0)
        dayOfWeek = 7;

    emit(dayOfWeek + '-' + hour, 1);
};

var thm_reduce = function (key, values) {
    return Array.sum(values);
}

/* GET home page. */
router.get('/', function(req, res, next) {
    res.render('index', { title: 'Express' });
});

router.get('/tagheatmap/:tag', function(req, res, next) {
    var the_tag = req.params.tag;
    var collection = db.collection("posts");
    collection.mapReduce(
        thm_map,
        thm_reduce,
        {
            query: { Tags: { $regex : '<' + the_tag + '>'} },
            out: {inline: 1}
        }, function(err, docs){
            var data = docs.map(function (d) {
                var arr = d._id.split('-');
                var dayw = parseInt(arr[0]);
                var hour = parseInt(arr[1]);
                return { day: dayw, hour: 1+hour, value: d.value};
            });

            // Render page
            res.render('tagheatmap',
                       {
                           title: 'Tag: ' + the_tag,
                           data: data
                       });
        });
});


module.exports = router;
