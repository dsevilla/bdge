package es.um.bdge.pig;

import java.io.IOException;
import java.util.Set;
import java.util.TreeSet;

import org.apache.pig.EvalFunc;
import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.BagFactory;
import org.apache.pig.data.DataBag;
import org.apache.pig.data.Tuple;

public class BagDistinct extends EvalFunc<DataBag>
{
    //private TupleFactory mTupleFactory = TupleFactory.getInstance();
    private BagFactory mBagFactory = BagFactory.getInstance();

    public DataBag exec(Tuple input) throws IOException
    {
        DataBag output = mBagFactory.newSortedBag(null);
        try {
            Object o = input.get(0);
            if (!(o instanceof DataBag)) {
                throw new IOException("Expected input to be a Bag, but got " + o.getClass().getName());
            }
            
            DataBag inputBag = (DataBag)o;
            if (inputBag.isDistinct())
            	return inputBag;
            else
            {
                Set<Object> uniqueElements = new TreeSet<Object>();
                
                inputBag.forEach(t -> {
                	if (!uniqueElements.contains(t))
                		uniqueElements.add(t);
                });
                
                uniqueElements.forEach(t -> output.add((Tuple)t));
            }            
        } catch (ExecException ee) {
            // error handling goes here
        }
        return output;
    }    
}
